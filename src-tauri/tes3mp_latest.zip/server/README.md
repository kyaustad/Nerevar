# CoreScripts

These are the scripts used to implement most of the essential server logic in TES3MP, including gameplay adjustments for multiplayer as well as state saving and loading.

* TES3MP version: 0.8.1
